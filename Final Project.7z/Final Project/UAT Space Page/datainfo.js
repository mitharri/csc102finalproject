/*
Mitchell Harris
6-11-22
Final Project
*/ 
        /*this is my array for the data in the table*/
        var missiondata = [40 + " seconds", 0, 0, 0, 30383.04, 2.34, 0, 24.25, 25.8, 477, 11, 0, -0.21, -0.59, 9.65, 0.14, 0.58, -0.24, 7.34, -3.49, -1.12]

        /*this is the function for the start button*/
        function showdata()
        {
            /*this is the code to reference the array*/
            document.getElementById("data1").innerHTML = missiondata[0];
            document.getElementById("data2").innerHTML = missiondata[1];
            document.getElementById("data3").innerHTML = missiondata[2];
            document.getElementById("data4").innerHTML = missiondata[3];
            document.getElementById("data5").innerHTML = missiondata[4];
            document.getElementById("data6").innerHTML = missiondata[5];
            document.getElementById("data7").innerHTML = missiondata[6];
            document.getElementById("data8").innerHTML = missiondata[7];
            document.getElementById("data9").innerHTML = missiondata[8];
            document.getElementById("data10").innerHTML = missiondata[9];
            document.getElementById("data11").innerHTML = missiondata[10];
            document.getElementById("data12").innerHTML = missiondata[11];
            document.getElementById("data13").innerHTML = missiondata[12];
            document.getElementById("data14").innerHTML = missiondata[13];
            document.getElementById("data15").innerHTML = missiondata[14];
            document.getElementById("data16").innerHTML = missiondata[15];
            document.getElementById("data17").innerHTML = missiondata[16];
            document.getElementById("data18").innerHTML = missiondata[17];
            document.getElementById("data19").innerHTML = missiondata[18];
            document.getElementById("data20").innerHTML = missiondata[19];
            document.getElementById("data21").innerHTML = missiondata[20];

        }

        /*this is the function for the stop button*/
        function cleardata()
        {
            /*this is the code to reset the mission data*/
            document.getElementById("data1").innerHTML = 0 + " seconds"/*i can add the seconds to the table from different locations--I though this was kinda cool*/;
            document.getElementById("data2").innerHTML = 0;
            document.getElementById("data3").innerHTML = 0;
            document.getElementById("data4").innerHTML = 0;
            document.getElementById("data5").innerHTML = 0;
            document.getElementById("data6").innerHTML = 0;
            document.getElementById("data7").innerHTML = 0;
            document.getElementById("data8").innerHTML = 0;
            document.getElementById("data9").innerHTML = 0;
            document.getElementById("data10").innerHTML = 0;
            document.getElementById("data11").innerHTML = 0;
            document.getElementById("data12").innerHTML = 0;
            document.getElementById("data13").innerHTML = 0;
            document.getElementById("data14").innerHTML = 0;
            document.getElementById("data15").innerHTML = 0;
            document.getElementById("data16").innerHTML = 0;
            document.getElementById("data17").innerHTML = 0;
            document.getElementById("data18").innerHTML = 0;
            document.getElementById("data19").innerHTML = 0;
            document.getElementById("data20").innerHTML = 0;
            document.getElementById("data21").innerHTML = 0;
        }

    