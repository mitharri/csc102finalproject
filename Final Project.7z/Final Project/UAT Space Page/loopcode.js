/*
Mitchell Harris
6-11-22
Final Project
*/ 

/*this is my code to log into the mission control page*/
/*this is the code to enter your name*/
var name = window.prompt("Enter your first and last name")

/*this is the code to enter your badge number */
var badgenumber = window.prompt("Enter your badge number")

/*this if format i use is while so the loop will continue until the parameters are met*/
/*this is the length for the name up to 20 characters*/
while(name.length <= 0 || name.length > 20)
{
    name = window.prompt("Enter a name between 1 and 20 characters...")
}

/*this is the while code for the badge*/
/*the badge code is 3 digits*/
while(badgenumber.length <= 2 || badgenumber.length > 3)
{
    badgenumber = window.prompt("Badge number is a 3 digit number.")
}

/*if log in parameters are met you are welcomed to the page*/
document.write("<h1>" + name + ", thank you for signing in.</h1>");


